package com.ahmedmohammed_comp304lab4_ex1.viewmodel

import android.content.Context
import android.content.pm.PackageManager
import android.location.Geocoder
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkRequest
import com.ahmedmohammed_comp304lab4_ex1.model.LocationDao
import com.ahmedmohammed_comp304lab4_ex1.model.LocationEntity
import com.ahmedmohammed_comp304lab4_ex1.workers.SyncWorker
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.util.concurrent.TimeUnit
import javax.inject.Inject

@HiltViewModel
class MapScreenViewModel @Inject constructor(
    private val locationDao: LocationDao,
    private val workManager: WorkManager
) : ViewModel() {

    init {
        scheduleSyncWorker()
    }


    private val _userLocation = mutableStateOf<LatLng?>(null)
    val userLocation: State<LatLng?> = _userLocation


    private val _selectedLocation = mutableStateOf<LatLng?>(null)
    val selectedLocation: State<LatLng?> = _selectedLocation

    private val _markers = mutableStateOf<List<Pair<String, LatLng>>>(emptyList())
    val markers: State<List<Pair<String, LatLng>>> = _markers




    fun fetchUserLocation(context: Context, fusedLocationClient: FusedLocationProviderClient) {

        if (ContextCompat.checkSelfPermission(
                context,
                android.Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            try {
                // Fetch the last known location
                fusedLocationClient.lastLocation.addOnSuccessListener { location ->
                    location?.let {
                        // Update the user's location in the state
                        val userLatLng = LatLng(it.latitude, it.longitude)
                        _userLocation.value = userLatLng
                    }
                }
            } catch (e: SecurityException) {
                Timber.e("Permission for location access was revoked: ${e.localizedMessage}")
            }
        } else {
            Timber.e("Location permission is not granted.")
        }
    }


    fun selectLocation(selectedPlace: String, context: Context) {
        viewModelScope.launch {
            val geocoder = Geocoder(context)
            val addresses = withContext(Dispatchers.IO) {

                geocoder.getFromLocationName(selectedPlace, 1)
            }
            if (!addresses.isNullOrEmpty()) {

                val address = addresses[0]
                val latLng = LatLng(address.latitude, address.longitude)
                _selectedLocation.value = latLng
            } else {
                Timber.tag("MapScreen").e("No location found for the selected place.")
            }
        }
    }


    fun addMarkerOnMap(map: GoogleMap, title: String, location: LatLng) {
        try {

            val markerOptions = MarkerOptions().position(location).title(title)
            map.addMarker(markerOptions)
            Timber.d("Marker added at location: $location with title: $title")
        } catch (e: Exception) {
            Timber.e("Failed to add marker: ${e.localizedMessage}")
        }
    }

    fun deleteMarker(location: LatLng) {
        _markers.value = _markers.value.filterNot { it.second == location }
    }

    fun saveUserLocation(location: LatLng) {
        viewModelScope.launch {
            val locationEntity = LocationEntity(
                latitude = location.latitude,
                longitude = location.longitude,
                timestamp = System.currentTimeMillis()
            )
            locationDao.insertLocation(locationEntity)
        }
    }

    // Fetch all saved locations
    fun fetchSavedLocations() {
        viewModelScope.launch {
            val savedLocations = locationDao.getAllLocations()
            // Handle retrieved locations (e.g., update UI or state)
        }
    }

    private fun scheduleSyncWorker() {
        val workRequest: WorkRequest = PeriodicWorkRequestBuilder<SyncWorker>(12, TimeUnit.MINUTES)
            .build()
        workManager.enqueue(workRequest)
    }
}