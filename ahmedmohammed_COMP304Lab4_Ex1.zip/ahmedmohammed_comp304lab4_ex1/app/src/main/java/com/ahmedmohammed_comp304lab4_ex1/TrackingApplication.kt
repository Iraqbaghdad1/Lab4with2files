package com.ahmedmohammed_comp304lab4_ex1

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class TrackingApplication : Application() {
}