package com.ahmedmohammed_comp304lab4_ex1.view

import android.content.pm.PackageManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SearchBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.ahmedmohammed_comp304lab4_ex1.viewmodel.MapScreenViewModel
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.Marker
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.Marker
import com.google.maps.android.compose.MarkerState
import com.google.maps.android.compose.rememberCameraPositionState
import timber.log.Timber

@Composable
fun MapScreen(mapViewModel: MapScreenViewModel , modifier: Modifier = Modifier) {

    val cameraPositionState = rememberCameraPositionState()

    val context = LocalContext.current

    val userLocation by mapViewModel.userLocation
    val fusedLocationClient = remember { LocationServices.getFusedLocationProviderClient(context) }


    val selectedLocation by mapViewModel.selectedLocation

    val markerList = remember { mutableStateListOf<Pair<LatLng, String>>() }

    var lastTappedLocation by remember { mutableStateOf<LatLng?>(null) }


    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {

            mapViewModel.fetchUserLocation(context, fusedLocationClient)
        } else {

            Timber.e("Location permission was denied by the user.")
        }
    }

    // Request the location permission when the composable is launched
    LaunchedEffect(Unit) {
        when (PackageManager.PERMISSION_GRANTED) {

            ContextCompat.checkSelfPermission(context, android.Manifest.permission.ACCESS_FINE_LOCATION) -> {

                mapViewModel.fetchUserLocation(context, fusedLocationClient)
            }
            else -> {

                permissionLauncher.launch(android.Manifest.permission.ACCESS_FINE_LOCATION)
            }
        }
    }


    Scaffold(
        modifier = Modifier.fillMaxSize(),
        floatingActionButton = {
            FloatingActionButton(
                onClick = {

                    lastTappedLocation?.let { location ->
                        mapViewModel.saveUserLocation(location)
                        Toast.makeText(
                            context,
                            "Location Saved: (${location.latitude}, ${location.longitude})",
                            Toast.LENGTH_SHORT
                        ).show()
                    } ?: run {
                        Toast.makeText(
                            context,
                            "No location to save! Tap on the map to select a location.",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                },
                content = { Icon(Icons.Default.Add, contentDescription = "Save Location") }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            Spacer(modifier = Modifier.height(18.dp))


            SearchBar(
                onPlaceSelected = { place ->
                    mapViewModel.selectLocation(place, context)
                }
            )


            GoogleMap(
                modifier = Modifier.fillMaxSize(),
                cameraPositionState = cameraPositionState,
                onMapClick = { latLng ->
                    // Add marker dynamically and track the tapped location
                    val markerTitle = "Marker at (${latLng.latitude}, ${latLng.longitude})"
                    lastTappedLocation = latLng
                    markerList.add(latLng to markerTitle)
                },
                onMapLongClick = { latLng ->
                    // Delete marker on long press
                    mapViewModel.deleteMarker(latLng)
                }
            ) {
                // Marker for user's location
                userLocation?.let {
                    Marker(
                        state = MarkerState(position = it),
                        title = "Your Location",
                        snippet = "This is where you are currently located."
                    )
                    cameraPositionState.position = CameraPosition.fromLatLngZoom(it, 10f)
                }


                selectedLocation?.let {
                    Marker(
                        state = MarkerState(position = it),
                        title = "Selected Location",
                        snippet = "This is the place you selected."
                    )
                    cameraPositionState.position = CameraPosition.fromLatLngZoom(it, 15f)
                }


                markerList.forEach { (location, title) ->
                    Marker(
                        state = MarkerState(position = location),
                        title = title
                    )
                }
            }
        }
    }
}